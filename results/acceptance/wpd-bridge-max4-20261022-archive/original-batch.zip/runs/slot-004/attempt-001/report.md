# IncidentLens — RESOLVED

Run: `run-94b9d2e207254dd78e66021f9c92fdf9`

Incident: `incident_3010`

## Root cause
postgres_slow_query

## Causal chain
- 2026-10-12T09:00:46+00:00 [incident_3010-E-003] postgres: Query execution sampled
- 2026-10-12T09:00:46+00:00 [incident_3010-E-004] postgres: query_latency_ms=7700 ms

## Predictions (not confirmed observations)
- Recurring in-window select-shape-7 executions remain multi-second while postgres connections stay far below the 100-connection limit, as at the observed 30-connection level.
- Postgres logs around 2026-10-12T08:55:00Z-09:10:00Z show the select-shape-7 execution completing with a multi-second duration and no connection-acquisition refusal or lock-wait entry.
- Backend and gateway request latency rises in the same interval as the 7700 ms postgres execution without pool-exhaustion or acquisition-timeout messages.

## Supporting evidence
- `incident_3010-E-003`
- `incident_3010-E-004`

## Rejected hypotheses
- postgres_connection_exhaustion: ['incident_3010-E-005']
- postgres_lock_contention: ['incident_3010-E-003']

## Unresolved


## Stop reason
Finalizing hyp-fa54443c13fbc99829780b65cb92a778117e548031b9ae28d162dc620361a0f3 (postgres / postgres_slow_query): supported by two independent observed sources (incident_3010-E-003 database slow-query record and incident_3010-E-004 query_latency_ms metric, both 7700 ms at 2026-10-12T09:00:46Z) with an observed cause discriminator (CPU wait event, empty blocked_by) and a sufficient prior review. Competing candidates resolved: hyp-e48a4fbb7ee5490e91fea1c2655f523977fa78863281d5805607cefd92a1641b (lock contention) rejected against incident_3010-E-003; hyp-51bd04666262ef67528352206d8217fe26919d211c65863ee2740d9edeef0a3b (connection exhaustion) rejected against incident_3010-E-005 (30 of 100 connections at the latency instant). All database, changes and postgres-metrics scopes are completed and exhausted; further log or backend-metric queries would add corroboration only, not discriminate mechanisms.

## Workflow
Diagnosis: RESOLVED
Remediation: NOT_STARTED
Workflow: FINISHED

## Termination
Reason: DIAGNOSIS_READY
Outcome: SUCCESS
Stop completed: True
Runtime failure: False
Failure stage: none
